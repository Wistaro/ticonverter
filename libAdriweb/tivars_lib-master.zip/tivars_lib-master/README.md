# tivars_lib
A PHP library to interact with TI-z80 (82/83/84 series) calculators files (programs, lists, matrices, etc.)
